import React,{PureComponent} from 'react';
import {HomewWapper,HomeRight,HomeLeft} from './style'
import List from './components/List';
import Topic from './components/Topic'
import Writer from './components/Writer'
// import Recommented from './components/Rcommened'
import Rcommened from './components/Rcommened';
// import axios from 'axios'
import {connect} from 'react-redux';
import {actionCreator} from './store'
import {BackTop} from './style'
class Home extends PureComponent{
    render(){
        const{ showScroll}=this.props;
        return(
            <HomewWapper>
                <HomeLeft>
                    <img alt='' src='//upload.jianshu.io/admin_banners/web_images/4691/6dcca4d07939d5d4c77b3dcc270001e304e08997.jpg?imageMogr2/auto-orient/strip|imageView2/1/w/1250/h/540' 
                    className='banner-img'/>
                    <Topic/>
                    <List/>
                </HomeLeft>
                <HomeRight>
                    <Rcommened/>
                    <Writer/>
                </HomeRight>
                { 
                    showScroll?<BackTop onClick={this.handleScrollTop}>回到顶部</BackTop>:null
                }
            </HomewWapper>
        )
    }
    handleScrollTop(){
        console.log(1)
        window.scrollTo(0,0)
    }
    componentDidMount(){
            this.props.changeHomeData();
            this.bindEvents();
    }
    componentWillUnmount(){
        window.removeEventListener('scroll',this.props.changeScrollTopShow)
    }
    bindEvents(){
        window.addEventListener('scroll',this.props.changeScrollTopShow)
    }

}
const mapState=(state)=>{
         return{
             showScroll:state.getIn(['home','showScroll'])
         }
}
const mapDiapatch=(dispatch)=>({
    changeHomeData(){
        const action=actionCreator.getHomeInfo();
        dispatch(action);
    },
    changeScrollTopShow(){
          //console.log(document.documentElement.scrollTop)
          const height=document.documentElement.scrollTop;
          if(height>100){
              const action=actionCreator.toggleTopShow(true)
              dispatch(action)
          }else{
            const action=actionCreator.toggleTopShow(false)
            dispatch(action)
          }
    }
})
export default connect(mapState,mapDiapatch)(Home);