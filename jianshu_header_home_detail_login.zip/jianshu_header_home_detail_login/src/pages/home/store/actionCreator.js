import axios from 'axios';
import * as actionType from './actionType'
const changeHomeData=(result)=>({
            type:actionType.CHANGE_HOME_DATA,
            RcommenedList:result.RcommenedList,
            artitleList:result.artitleList,
            toppicList:result.toppicList
})
const addHomeList=(list,nextPage)=>({
     type:actionType.ADD_HOME_LIST,
     list:list.artitleList,
     nextPage
})
export  const  getHomeInfo=()=>{
    //redux-thunk 返回一个函数
    return(dispatch)=>{
    axios.get('/api/home.json').then((res)=>{
        //console.log(res);
        const result=res.data.data; 
        const action=changeHomeData(result);
        dispatch(action);
    })
   }
}
export const getMoreList=(page)=>{
    return(dispatch)=>{
        //console.log('1')
        axios.get('/api/homeList.json?page='+page).then((res)=>{
            const list=res.data.data;
            const action=addHomeList(list,page+1);
            dispatch(action);
        })
    }
}
export const toggleTopShow=(show)=>({
    type:actionType.TOGGLE_SCROLL_SHOW,
    show
})
