export const  CHANGE_HOME_DATA="home/CHANGE_HOME_DATA";
export const  ADD_HOME_LIST="home/ADD_HOME_LIST";
export const TOGGLE_SCROLL_SHOW='home/TOGGLE_SCROLL_SHOW';