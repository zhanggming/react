export const CHANGE_LOGIN='login/CHANGE_LOGIN';
export const LOGOUT='home/LOGOUT';