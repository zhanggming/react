import {fromJS} from 'immutable';
import * as actionType from './actionType';
const defaultState=fromJS({
      islogin:false
})
export default (state=defaultState,action)=>{
   // console.log(action.value)
    switch(action.type){
        case actionType.CHANGE_LOGIN:
        return state.set('islogin',action.value);
        case actionType.LOGOUT:
        return state.set('islogin',action.value);
        default:
        return state;
    }
}