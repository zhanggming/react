import React,{PureComponent} from 'react';
import {LoginwWapper,LoginBox,Input, Button} from './style'
import {connect} from 'react-redux'
import {actionCreator} from './store'
import {Redirect} from 'react-router-dom'
class Login extends PureComponent{
    render(){
        const {login}=this.props;
        if(!login){
            return(
                <LoginwWapper>
                    <LoginBox>
                        <Input placeholder='账号' ref={(input)=>{this.account=input}}/>
                        <Input placeholder='密码' type='password' ref={(input)=>{this.password=input}}/>
                        <Button onClick={()=>this.props.handleClick(this.account,this.password)}>登陆</Button>
                    </LoginBox>
                </LoginwWapper>
             )
        }else{
            return <Redirect to='/'/>
        }
    }
}
const mapState=(state)=>{
    return{
        login:state.getIn(['login','islogin'])
    }
}
const mapDispatch=(dispatch)=>({
    handleClick(accountElement,passwordElement){
          //console.log(accountElement.value,passwordElement.value);
          dispatch(actionCreator.login(accountElement.value,passwordElement.value))
    }
})
export default connect(mapState,mapDispatch)(Login);