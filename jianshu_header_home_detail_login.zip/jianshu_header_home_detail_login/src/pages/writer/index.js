import React,{PureComponent} from 'react';
import {connect} from 'react-redux'
// import {actionCreator} from './store'
import {Redirect} from 'react-router-dom'
class Writer extends PureComponent{
    render(){
        const {login}=this.props;
        if(login){
            return(
               <div>写文章</div>
             )
        }else{
            return <Redirect to='/login'/>
        }
    }
}
const mapState=(state)=>{
    return{
        login:state.getIn(['login','islogin'])
    }
}
const mapDispatch=(dispatch)=>({
})
export default connect(mapState,mapDispatch)(Writer );