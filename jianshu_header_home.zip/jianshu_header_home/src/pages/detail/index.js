import React,{PureComponent} from 'react';
import {DeatilwWapper,Header} from './style'
class Detail extends PureComponent{
    render(){
        return(
            <DeatilwWapper>
                <Header>Detail</Header>
            </DeatilwWapper>
        )
    }
}
export default Detail;