export const SEARCH_FOCUS='header/SEARCH_FOCUS';
export const SEARCH_BLUR='head/SEARCH_BLUR';
export const CHANGE_LIST='head/CHANGE_LIST';
export const MOUSE_ENTER='head/MOUSE_ENTER';
export const MOUSE_LEAVE='head/MOUSE_LEAVE';
export const CHANGE_PAGE='CHANGE_PAGE';