import { createGlobalStyle } from 'styled-components'
export const GlobalIcon =createGlobalStyle`
@font-face {font-family: "iconfont";
  src: url('iconfont.eot?t=1565700209922'); /* IE9 */
  src: url('iconfont.eot?t=1565700209922#iefix') format('embedded-opentype'), /* IE6-IE8 */
  url('data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAAQUAAsAAAAACGQAAAPFAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHEIGVgCDKgqEBINYATYCJAMUCwwABCAFhG0HTxtjBxFVnHvIfhzYMeTvcDMYLMo4LJYLNvd8KK/3DbJNJ58+iUxSG0cY2cLO1nQd7g8jIkyn7HnqWf5HfrQ7Des8TqMUQoJwYCnXSx7QBrLj76f+2GwCefZsLpFJmbSmABwPaEARbQUy0ACZqG8Yu4nyIA4DASDgh3CQ/MLyesjgAKMIANKtc8fWkFMG8JpcAhkElpKFHGQWJMh0Mj0PYCb/PnmDWCIDFBIDmFjdoaAdsp+7vqxho8xHM4pBOJ4NgLYMYADCAXCAdCl1tAMLw+FgEE4yRzIAGfajwHPX50kva0xToiSK9sKv/csTABgoOAhALAAKG5GaHeHAc1eMgAHPExFQ4HkSAg68rBHdR7YEABBixlIArwBoPngIBQcFdXSUZVfF3sPNZmD9gRu4fr2e1KvEatVHG5qWTBl1o0Y/aJi3gL3QbOpFV6VxkwV+YplHo9b7lKmAIOKwmHKRjNb10fzCdHX7JozarEw9Roiud4zSR48W2oJ5qHdppy7yp9esO+vl1nSJd0d3fenWXTsC1D03wodqh6zEMLSJut64oU61Zqnzp24d3Wc2XpJXsIVh/NnfuPG9qL45dOL27RNp9kjwVvYB/vfvDjTNW/1nTKrebPVaONyh6Epw/pX2dqbKM7pkVqk0t03nTCv/k9m334nkKCLlRPYM0TrbNlfKslOfttD7nfN0/eMV8CnAD/9sVvSih6bGNyGUTKqEAwlv7+z54sHkbSV3lvbe6TPU3UNx2+b1siSuyeofXa6eEysKXSsLkDLLbefOHqH9ctni8+cXEylTjWxx7M3tF/q8vNMWX9X370Y6ZO3aIbKUynY2hMk8xhV7IhkAYJrsMOOM0awxGx69ydYxv9/+G7z3CiAt7dO/yQoHANwadKW3mGeOQg97/p2wtfAnC1vWcFcMjNLsSiywnZLoxChQgCAAPzcOOPmN43IVxTZC1oUiUA34AiPzxzk1HCSKeLCQZYEQpl2ucEZSZA0BhHoJQDh4A2XnEDAOPjinfkHi5g8WDjEQtJw3VATWWeQRSkYD6glBz5NFZhZB7gHddZCUFHP6BWkLPqjyMhtrcUIaY8p2czWzBUvzCHvhOByGGRaaO9Sce+alKQpb9qRcz2Mk5CFIYsgAyhMItNnE0uZM5D5/gJyrgUQ1VR3OC0Q2oX1QyZUt8FYxtaq6lu6bG6fGmJWHWWQ2AnvRhgYYnoGlvF8HaSznewQXjUJqZNsq8vlV4zNuARDAblKUMMKJRCzgt4QpyZG7G5icaY+6D5PoICdnZBeoPooAAAAA') format('woff2'),
  url('iconfont.woff?t=1565700209922') format('woff'),
  url('iconfont.ttf?t=1565700209922') format('truetype'), /* chrome, firefox, opera, Safari, Android, iOS 4.2+ */
  url('iconfont.svg?t=1565700209922#iconfont') format('svg'); /* iOS 4.1- */
}
.iconfont {
  font-family: "iconfont" !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.icon-spin:before {
  content: "\e851";
}

.icon-Aa:before {
  content: "\e636";
}

.icon-icon-checkin:before {
  content: "\e615";
}

.icon-fangdajing:before {
  content: "\e637";
}

`

