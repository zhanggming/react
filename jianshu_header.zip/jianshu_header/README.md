React项目技术栈：
WEB端：
    "immutable": "^4.0.0-rc.12",
    "react": "^16.8.6",
    "react-dom": "^16.8.6",
    "react-redux": "^7.1.0",
    "react-scripts": "3.0.1",
    "react-transition-group": "^4.2.2",
    "redux": "^4.0.4",
    "redux-immutable": "^4.0.0",
    "styled-components": "^4.3.2"
1.styled-components 管理样式 4.3.2
2.reset.css PC端浏览器样式统一
3.iconfont
4.代码拆分