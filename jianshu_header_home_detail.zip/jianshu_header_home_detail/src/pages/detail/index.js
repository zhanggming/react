import React,{PureComponent} from 'react';
import {DeatilwWapper,Header,Content} from './style'
import {connect} from 'react-redux'
import {actionCreator} from './store'
class Detail extends PureComponent{
    render(){
        console.log(this.props.title)
        return(
            <DeatilwWapper>
                <Header>{this.props.title}</Header>
                <Content>
                    <p>
                     {this.props.content}
                    </p>
                </Content>
            </DeatilwWapper>
        )
    }
    componentDidMount(){
        this.props.getDetail(this.props.match.params.id);
    }
}
const mapState=(state)=>{
    return{
        title:state.getIn(['detail','title']),
        content:state.getIn(['detail','content'])
    }
}
const mapDispatch=(dispatch)=>({
    getDetail(id){
        dispatch(actionCreator.getDetail(id));
    }
})
export default connect(mapState,mapDispatch)(Detail);