import React,{PureComponent} from 'react';
import {RcommenedWrapper,RcommenedItem} from '../style'
import {connect} from 'react-redux'
class Rcommened extends PureComponent{
    render(){
        const {list}=this.props;
        return(
            <RcommenedWrapper>
                {
                  list.map((item)=>{
                      return(
                        <RcommenedItem key={item.get('id')}
                        imgUrl={item.get('imgUrl')}>
                     </RcommenedItem>
                      )
                  })
                }
            </RcommenedWrapper>
        )
    }
}
const mapState=(state)=>{
    return{
        list:state.getIn(['home','RcommenedList'])
    }
}
export default connect(mapState,null)(Rcommened);