import React,{PureComponent} from 'react';
import {RWriterWrapper} from '../style'
class Writer extends PureComponent{
    render(){
        return(
            <RWriterWrapper>Writer</RWriterWrapper>
        )
    }
}
export default Writer;