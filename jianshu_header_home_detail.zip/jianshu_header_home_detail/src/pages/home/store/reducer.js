//immutable
import {fromJS} from 'immutable';
import * as actionType from './actionType'
const defaultState=fromJS({
        toppicList:[],
        artitleList:[],
        RcommenedList:[],
        artitPage:1,
        showScroll:false
});
const changeHomeData=(state,action)=>{
       return  state.merge({
        toppicList:fromJS(action.toppicList),
        artitleList:fromJS(action.artitleList),
        RcommenedList:fromJS(action.RcommenedList)
    })
}
const addArticleList=(state,action)=>{
    return state.merge({
        artitleList:state.get('artitleList').concat(fromJS(action.list)),
        artitPage:action.nextPage
    })
}
//immutable
export default (state=defaultState,action)=>{
    switch(action.type){
        case actionType.CHANGE_HOME_DATA:
        //state.set('toppicList','action.toppicList')
        //一次合并多个属性
        return  changeHomeData(state,action)
        case actionType.ADD_HOME_LIST:
        //state.set('toppicList','action.toppicList')
        //一次合并多个属性
        return  addArticleList(state,action)
        case actionType.TOGGLE_SCROLL_SHOW:
        //state.set('toppicList','action.toppicList')
        //一次合并多个属性
        return  state.set('showScroll',action.show)
        default:
        return state;
    }
}